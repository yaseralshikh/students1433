<script>
    "use strict";

    window.addEventListener('alert', event => {
        var _event$detail$message, _event$detail$type;

        Swal.fire(Object.assign({}, {
            title: (_event$detail$message = event.detail.message) !== null && _event$detail$message !== void 0 ? _event$detail$message : '',
            icon: (_event$detail$type = event.detail.type) !== null && _event$detail$type !== void 0 ? _event$detail$type : null,
        }, event.detail.options));
    });
    window.addEventListener('confirming', confirming => {
        window.addEventListener(confirming.detail, event => {
            var _event$detail$options;

            Swal.fire(Object.assign(
                {}, {
                    confirmButtonText: (_event$detail$options = event.detail.options.confirmButtonText) !== null && _event$detail$options !== void 0 ? _event$detail$options : 'Yes',
                }, event.detail.options
            )).then(result => {
                if (result.isConfirmed) {
                    Livewire.emit(event.detail.onConfirmed, event.detail.options["inputAttributes"]);
                } else {
                    const cancelCallback = event.detail.onCancelled;

                    if (!cancelCallback) {
                        return;
                    }

                    Livewire.emit(cancelCallback);
                }
            });
        });
    });
</script>

<?php if(session()->has('livewire-alert')): ?>
    <script>
        "use strict";

        window.onload = event => {
            var _flash$message, _flash$type;

            const flash = <?php echo json_encode(session('livewire-alert'), 15, 512) ?>;
            Swal.fire({
                title: (_flash$message = flash.message) !== null && _flash$message !== void 0 ? _flash$message : '',
                icon: (_flash$type = flash.type) !== null && _flash$type !== void 0 ? _flash$type : null,
                ...flash.options
            });
        };
    </script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\students1443\vendor\jantinnerezo\livewire-alert\src/../resources/views/components/scripts.blade.php ENDPATH**/ ?>