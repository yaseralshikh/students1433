<?php return array (
  'school-dropdown' => 'App\\Http\\Livewire\\SchoolDropdown',
);