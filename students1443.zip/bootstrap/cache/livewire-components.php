<?php return array (
  'dashboard' => 'App\\Http\\Livewire\\Dashboard',
  'school-dropdown' => 'App\\Http\\Livewire\\SchoolDropdown',
);